import React, { useState } from 'react';
import { Button, Alert, Form } from 'react-bootstrap';
import './Login.css';
import AuthService from '../Services/AuthService';
import { useNavigate } from 'react-router-dom';

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState(null); // State to hold login error
    const navigate = useNavigate(); // Hook for navigation

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const result = await AuthService.login(email, password);
            const nextPage = result.user.role === 'admin' ? '/update-password' : `/add-certifications/${result.user.user_id}`;
            navigate(nextPage);
        } catch (error) {
            console.error('Login failed:', error);
            setError('Invalid email or password'); // Set login error message
        }
    };

    return (
        <div className="form-head">
            <center className="login-head">Login</center>
            <br />
            {error && <Alert variant="danger">{error}</Alert>} 
            <Form onSubmit={handleSubmit}>
                <Form.Group controlId="formBasicEmail">
                    <Form.Label>Email Id</Form.Label>
                    <Form.Control
                        type="email"
                        placeholder="Enter email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                </Form.Group>
                

                <Form.Group controlId="formBasicPassword">
                    <Form.Label>Password</Form.Label>
                    <Form.Control
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                </Form.Group>
                
                
                <Button className="Button" type="submit">Log In</Button>
              
            </Form>
        </div>
    );
};

export default Login;
