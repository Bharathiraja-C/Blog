// services/UserService.js
import axios from 'axios';

const UserService = {
    async createUser(email, password, role) {
        try {
            const response = await axios.post('http://localhost:5000/api/create-user', { email, password, role });
            return response.data;
        } catch (error) {
            throw error.response.data;
        }
    },

    async updatePassword(email, temporaryPassword, newPassword) {
        try {
            const response = await axios.post('http://localhost:5000/api/update-password', {
                email,
                temporaryPassword,
                newPassword
            });
            return response.data;
        } catch (error) {
            throw error.response.data;
        }
    },

    async addCertification(userId, certificationData) {
        try {
            console.log('UserId:',userId)
            const response = await axios.post(`http://localhost:5000/api/add-certifications/${userId}`, certificationData);
            return response.data;
        } catch (error) {
            throw error.response.data;
        }
    }
};

export default UserService;
