const UserModel = require('../models/UserModel');

const AuthController = {
    async login(req, res) {
        const { email, password  } = req.body;

        try {
            const user = await UserModel.findUserByEmailAndPassword(email, password);

            if (user) {
                // User found, send success response
                res.status(200).json({ message: 'Login successful', user });
            } else {
                // User not found or incorrect credentials, send error response
                res.status(401).json({ error: 'Invalid email or password' });
            }
        } catch (error) {
            // Error handling
            console.error('Error during login:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    }
    
};

module.exports = AuthController;
