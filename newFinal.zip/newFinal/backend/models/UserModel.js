// userModel.js
const { Pool } = require('pg');
const bcrypt = require('bcrypt');

const pool = new Pool({
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  port: process.env.DB_PORT
});

pool.connect()
  .then(() => console.log('Connected to PostgreSQL database'))
  .catch(err => console.error('Error connecting to PostgreSQL database:', err));

const UserModel = {
  async createUser(email, password, role) {
    try {
      const query = {
        text: 'INSERT INTO users (username, password, role) VALUES ($1, $2, $3)',
        values: [email, password, role],
      };

      await pool.query(query);
    } catch (error) {
      throw error;
    }
  },

  async findUserByEmailAndPassword(email,password) {
    const query = {
      text: 'SELECT * FROM users WHERE username = $1 and password= $2',
      values: [email,password],
    };

    try {
      const result = await pool.query(query);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  async getUserByEmail(email){
    const query = {
      text: 'SELECT * FROM users WHERE username = $1',
      values: [email],
    };

    try {
      const result = await pool.query(query);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },

  async comparePassword(user, password) {
    try {
      // Compare the provided password with the hashed password stored in the database
      const passwordMatch = await bcrypt.compare(password, user.password);
      return passwordMatch;
    } catch (error) {
      throw error;
    }
  },

  async updatePassword(email, newPassword) {
    try {
      // Hash the new password
      //const hashedPassword = await bcrypt.hash(newPassword, 10);

      // Update the password in the database
      const query = {
        text: 'UPDATE users SET password = $1 WHERE username = $2',
        values: [newPassword, email],
      };

      await pool.query(query);
    } catch (error) {
      throw error;
    }
  }
};

module.exports = UserModel;
