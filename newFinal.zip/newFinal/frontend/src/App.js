import logo from './logo.svg';
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import './App.css';
import Login from './Pages/Login';
import UserCreation from './Pages/UserCreation';
import UpdatePassword from './Pages/UpdatePassword';
import AddCertifications from './Pages/addCertifications'; // Import AddCertifications component
import { useParams } from 'react-router-dom'; // Import useParams hook

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<Login />} />
        <Route path='/create-user' element={<UserCreation />} />
        <Route path='/update-password' element={<UpdatePassword />} />
        {/* Dynamically pass userId to AddCertifications */}
        <Route path='/add-certifications/:userId' element={<AddCertificationsWithUserId />} />
      </Routes>
    </BrowserRouter>
  );
}

// Component to pass userId to AddCertifications
const AddCertificationsWithUserId = () => {
  const { userId } = useParams(); // Get userId from URL params
  return <AddCertifications userId={userId} />; // Pass userId as prop to AddCertifications
};

export default App;
