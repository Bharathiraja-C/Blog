import React, { useState } from 'react';
import { Button, Form } from 'react-bootstrap';
import UserService from '../Services/UserService'; // Import UserService
import './Login.css';

const AddCertification = ({ userId }) => {
    const [certifications, setCertifications] = useState([{ id: Math.random().toString(36).substr(2, 9), certificationName: '', certificationFile: null, projectExperience: '', proficiencyLevel: '' }]);

    const handleCertificationChange = (index, key, value) => {
        const updatedCertifications = [...certifications];
        updatedCertifications[index][key] = value;
        setCertifications(updatedCertifications);
    };

    const handleFileChange = (index, event) => {
        const updatedCertifications = [...certifications];
        updatedCertifications[index].certificationFile = event.target.files[0];
        setCertifications(updatedCertifications);
    };

    const addCertification = () => {
        setCertifications([...certifications, { id: Math.random().toString(36).substr(2, 9), certificationName: '', certificationFile: null, projectExperience: '', proficiencyLevel: '' }]);
    };

    const removeCertification = (id) => {
        setCertifications(certifications.filter(certification => certification.id !== id));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await Promise.all(certifications.map(async (certification) => {
                await UserService.addCertification(userId, certification);
            }));
            console.log('Certifications added successfully');
            // You can redirect or perform any other action after adding certifications
        } catch (error) {
            console.error('Error adding certifications:', error);
            // Handle error (e.g., display error message to user)
        }
    };

    return (
        <div className="form-head">
            <center className="login-head">Add Certifications</center>
            <Form onSubmit={handleSubmit}>
                {certifications.map((certification, index) => (
                    <div key={certification.id}>
                        <Form.Group controlId={`certificationName${index}`}>
                            <Form.Label>Certification Name</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Enter certification name"
                                value={certification.certificationName}
                                onChange={(e) => handleCertificationChange(index, 'certificationName', e.target.value)}
                            />
                        </Form.Group>

                        <Form.Group controlId={`certificationFile${index}`}>
                            <Form.Label>Certification File</Form.Label>
                            <Form.Control
                                type="file"
                                accept=".pdf,.doc,.docx" // Define accepted file types
                                onChange={(e) => handleFileChange(index, e)}
                            />
                        </Form.Group>

                        <Form.Group controlId={`projectExperience${index}`}>
                            <Form.Label>Project Experience</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Enter project experience"
                                value={certification.projectExperience}
                                onChange={(e) => handleCertificationChange(index, 'projectExperience', e.target.value)}
                            />
                        </Form.Group>

                        <Form.Group controlId={`proficiencyLevel${index}`}>
                            <Form.Label>Proficiency Level</Form.Label>
                            <br/>
                            <Form.Control
                                as="select"
                                value={certification.proficiencyLevel}
                                onChange={(e) => handleCertificationChange(index, 'proficiencyLevel', e.target.value)}
                            >
                                <option value="">Select proficiency level</option>
                                <option value="Beginner">Beginner</option>
                                <option value="Intermediate">Intermediate</option>
                                <option value="Advanced">Advanced</option>
                            </Form.Control>
                        </Form.Group>
                    </div>
                ))}
                <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '10px' }}>
                    <Button variant="success" onClick={addCertification} style={{ marginRight: '10px' }}>+</Button>
                    <Button variant="danger" onClick={() => removeCertification(certifications[certifications.length - 1].id)}>-</Button>
                </div>
                <br/>
                <Button type="submit">Submit</Button>
            </Form>
        </div>
    );
};

export default AddCertification;
