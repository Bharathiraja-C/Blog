// CreateUser.jsx
import React, { useState } from 'react';
import { Button,  Form } from 'react-bootstrap';
import UserService from '../Services/UserService'; // Import the UserService

const CreateUser = () => {
    const [email, setEmail] = useState('');
    const [address, setAddress] = useState('');
    const [phone, setPhone] = useState('');
    const [role, setRole] = useState('');
    

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const result = await UserService.createUser(email, address,role);
            console.log('User created successfully:', result);
            // Handle success (e.g., show a success message)
        } catch (error) {
            console.error('Error creating user:', error);
            // Handle error (e.g., display an error message)
        }
    };

    return (
        <div className="form-head">
            <center className="create-user-head">Create New User</center>
            <br />
            <Form onSubmit={handleSubmit}>
                <Form.Group controlId="formBasicEmail">
                    <Form.Label>Email</Form.Label>
                    <Form.Control
                        type="email"
                        placeholder="Enter email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                </Form.Group>
                

                <Form.Group controlId="formBasicPassword">
                    <Form.Label>Password</Form.Label>
                    <Form.Control
                        type="text"
                        placeholder="address"
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                    />
                </Form.Group>

                <Form.Group controlId="formBasicPassword">
                    <Form.Label>Phone</Form.Label>
                    <Form.Control
                        type="text"
                        placeholder="phone"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                    />
                </Form.Group>
                <Form.Group controlId="formBasicPassword1">
                    <Form.Label>role</Form.Label>
                    <Form.Control
                        type="text"
                        placeholder="role"
                        value={role}
                        onChange={(e) => setRole(e.target.value)}
                    />
                </Form.Group>
                <Button className="Button" type="submit">Create User</Button>
            </Form>
        </div>
    );
};

export default CreateUser;
